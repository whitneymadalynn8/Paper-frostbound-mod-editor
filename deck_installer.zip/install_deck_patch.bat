@echo off
cd /d "%~dp0"
echo FrostBound deck patch - one-time install
echo.
FrostBoundTerrainLoader.exe --install
FrostBoundTerrainLoader.exe --install-deck
echo.
echo If installation succeeded, start the game normally and create a new game.
pause

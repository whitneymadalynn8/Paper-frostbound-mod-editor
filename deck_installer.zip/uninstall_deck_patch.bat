@echo off
cd /d "%~dp0"
echo FrostBound deck patch - uninstall
FrostBoundTerrainLoader.exe --uninstall-deck
pause

@echo off
cd /d "%~dp0"
echo FrostBound terrain patch - one-time install
echo.
FrostBoundTerrainLoader.exe --install
echo.
echo If installation succeeded, start the game normally. No loader is needed afterwards.
pause
